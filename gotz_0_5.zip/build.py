import json, base64, zipfile, os
ROOT = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.dirname(ROOT)
hub = json.load(open(os.path.join(ROOT, 'gotz_math.json')))
sizes = json.load(open(os.path.join(OUT, 'assets', '_sizes.json')))
assets = {}
for key, meta in sizes.items():
    b = open(os.path.join(OUT, 'assets', key + '.png'), 'rb').read()
    assets[key] = {'href': 'data:image/png;base64,' + base64.b64encode(b).decode(), 'w': meta['w'], 'h': meta['h']}
asset_for = {k: v for k, v in hub['assets'].items()}
used = {}
for k, name in asset_for.items():
    used[k] = assets[name]
tpl = open(os.path.join(ROOT, 'template.html')).read()
html = tpl.replace('__HUB_JSON__', json.dumps(hub)).replace('__ASSETS_JSON__', json.dumps(used))
open(os.path.join(OUT, 'gotz_0_5.html'), 'w').write(html)

BULB = "M -22 0 C -46 -30 -46 -100 -34 -132 C -26 -152 -12 -162 0 -162 C 12 -162 26 -152 34 -132 C 46 -100 46 -30 22 0 Z"
T = hub['tool_scale']; UNIT = hub['unit_px'] * T
SX = (hub['bulb']['width_units'] * UNIT / 2) / hub['bulb']['half_width_px']
SHAPE = 'fill="#ffffff" stroke="#111110" stroke-width="1.5" vector-effect="non-scaling-stroke"'
def path(bid, x, y, L):
    return f'<path data-bone="{bid}" d="{BULB}" transform="translate({x:.2f} {y:.2f}) scale({SX:.4f} {-L/hub["bulb"]["length_px"]:.4f})" {SHAPE}/>'
def dot(x, y, r=4, c='#7F77DD'):
    return f'<circle cx="{x:.2f}" cy="{y:.2f}" r="{r}" fill="{c}"/>'
W = hub['wrist']
out = []
u = hub['finger_units']
for F in hub['fingers']:
    fs = F['scale']; f = F['id']
    L = {k: UNIT * u[k] * fs for k in ('meta', 'prox', 'mid', 'dist')}
    K = (W[0], W[1] + L['meta']); M = (K[0], K[1] + L['prox']); D = (M[0], M[1] + L['mid']); TIP = D[1] + L['dist']
    g = f'<g transform="rotate({F["rest"]} {W[0]} {W[1]})">' + path(f+'.meta', W[0], W[1], L['meta']) + dot(*W)
    g += f'<g transform="rotate(0 {K[0]} {K[1]})">' + dot(*K)
    g += '<g>' + path(f+'.prox', K[0], K[1], L['prox'])
    g += f'<g transform="rotate(0 {M[0]} {M[1]})">' + path(f+'.mid', M[0], M[1], L['mid']) + dot(*M)
    g += f'<g transform="rotate(0 {D[0]} {D[1]})">' + path(f+'.dist', D[0], D[1], L['dist']) + dot(*D) + dot(D[0], TIP - 4, 3, '#E24B4A')
    g += '</g></g></g></g></g>'
    out.append(g)
TU = hub['thumb']['units']
TL = {k: UNIT * TU[k] for k in ('c1', 'c2', 'mid', 'dist')}
TC2 = (W[0], W[1] + TL['c1']); TM = (TC2[0], TC2[1] + TL['c2']); TD = (TM[0], TM[1] + TL['mid']); TTIP = TD[1] + TL['dist']
th = f'<g transform="rotate({hub["thumb"]["rest"]} {W[0]} {W[1]})">' + path('thumb.c1', W[0], W[1], TL['c1']) + dot(*W)
th += f'<g transform="rotate(0 {TC2[0]} {TC2[1]})">' + path('thumb.c2', TC2[0], TC2[1], TL['c2']) + dot(*TC2)
th += f'<g transform="rotate(0 {TM[0]} {TM[1]})">' + path('thumb.mid', TM[0], TM[1], TL['mid']) + dot(*TM)
th += f'<g transform="rotate(0 {TD[0]} {TD[1]})">' + path('thumb.dist', TD[0], TD[1], TL['dist']) + dot(*TD) + dot(TD[0], TTIP - 4, 3, '#E24B4A')
th += '</g></g></g></g>'
out.append(th)
vb = hub['viewbox']
svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{vb[0]} {vb[1]} {vb[2]} {vb[3]}" width="{vb[2]}" height="{vb[3]}">\n'
       f'<title>Gotz 0.5 hand, rest pose</title>\n'
       f'<rect x="{vb[0]}" y="{vb[1]}" width="{vb[2]}" height="{vb[3]}" fill="#ffffff"/>\n'
       + '\n'.join(out) + '\n</svg>\n')
open(os.path.join(OUT, 'gotz_0_5.svg'), 'w').write(svg)
with zipfile.ZipFile(os.path.join(OUT, 'gotz_0_5.zip'), 'w', zipfile.ZIP_DEFLATED) as z:
    z.write(os.path.join(OUT, 'gotz_0_5.html'), 'gotz_0_5.html')
    z.write(os.path.join(OUT, 'gotz_0_5.svg'), 'gotz_0_5.svg')
    z.write(os.path.join(ROOT, 'gotz_math.json'), 'gotz_math.json')
print('built', len(html), len(svg))
